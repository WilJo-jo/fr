var a = "afpa_dwwm";
var l = a.length
alert(a + " est de longueur "+ l); 
var age;
var prenom;
prenom = prompt(" quel est votre prénom ?");
age = prompt(" quel age avez-vous ?");
alert("votre prénom est "+ prenom + " et vous avez "+ age);